/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10444823.sectionb.prog6112;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author ntsan
 */
public class student {
    
     //Joyce Farrel - Java Programming 9th Edition
    private int id;
    private double mark;
    private double avg;
    private String name;
    
    
    Scanner input = new Scanner(System.in);

    //Contructor 
    public student(int id, double mark, double avg, String name) {
        this.id = id;
        this.mark = mark;
        this.avg = avg;
        this.name = name;
    }
    public int getId() {    
        return id;
    }

    public double getMark() {
        return mark;
    }

    public double getAvg() {
        return avg;
    }

    public String getName() {
        return name;
    }

    //getters
    public Scanner getInput() {   
        return input;
    }

    //setters

    public void setId(int id) {
        this.id = id;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setInput(Scanner input) {
        this.input = input;
    }
    
    
    

    //Method used to save the student infromation
    //Joyce Farrel - Java Programming 9th Edition
    //Option 1
   public void saveStudent(ArrayList<student> students){
       
       //Prompting and caputuring ID
       System.out.println("Enter Student ID: ");
       id = input.nextInt();
       input.nextLine();
       
       //Prompting and caputuring name
       System.out.println("Enter Student name:");
       name = input.nextLine();
       
       //Prompting and caputuring Mark
       System.out.println("Enter Student Mark: ");
       mark = input.nextDouble();
       
       students.add(new student (id, mark, avg, name));
       System.out.println("Student has been added succesfully! \n");
       
   }
   
   //Method used to search for the student using the ID
   // Assisted by Microsoft Copilot (AI)
    //Joyce Farrel - Java Programming 9th Edition
    //Option 2
    public void searchStudent(ArrayList<student> students) {
        
        System.out.print("Enter Student ID to search: ");
        
        int sId = input.nextInt();

        for (student s : students) {
            if (s.id == sId) {
                System.out.println("Student Found:");
                System.out.println("ID: " + s.id + ", Name: " + s.name + ", Mark: " + s.mark);
                return;
            }
        }
        
        System.out.println(" Student not found.\n");
    }
   
    //Method used to remove the student using the ID
    //Joyce Farrel - Java Programming 9th Edition
    //Option 3
    public void removeStudent(ArrayList<student> students){
        
        System.out.println("Enter Student ID to remove: ");
        
        int sId = input.nextInt();
        
        for (student s : students){
            
            if(s.id == sId){
                students.remove(s);
                
                System.out.println("Student has been successfully removed \n");
                
                return;
            }
        }
        
        System.out.println("student has not been found or invalid entry \n");
    }
    
    //Method used to display all the students recorded
    // Assisted by Microsoft Copilot (AI)
    //Joyce Farrel - Java Programming 9th Edition
    //Option 4
    public void printReport(ArrayList<student> students){
        
        if (students.isEmpty()){
            
            System.out.println("No students have been recorded yet. Please record \n");
            
            return;
        }
        
        // Sort students by marks (highest → lowest)
        Collections.sort(students, Comparator.comparingDouble(student::getMark).reversed());
        
        System.out.println("\n  Student Report ");
        
        for (student s: students){
            
            System.out.println("ID:" + s.id + ",Name: " + s.name + ", Mark:" + s.mark);
        }
       
        // Show class average
        avg = calAvg(students);
        System.out.println("\nClass Average: " + avg);

        // Show pass/fail summary
        System.out.println("Pass/Fail Report:");
        for (student s : students) {
            String result = (s.mark >= 50) ? "PASS" : "FAIL";
            System.out.println("Student " + s.name + " (" + s.id + "): " + result);
        }
        System.out.println("-------------------\n");
          
    }
    
 
    //Joyce Farrel - Java Programming 9th Edition
    private double calAvg(ArrayList<student> students){
        
        double total  = 0;
        
        for(student s: students){
            
            total += s.mark;
        }
        
        return total / students.size();
    }
    
    //Joyce Farrel - Java Programming 9th Edition
   public  double printMark(){
       
       return mark;
   }
}
