/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10444823.sectionb.prog6112;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ntsan
 */
public class ST10444823SectionBPROG6112 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Initial menu prompt
        //Joyce Farrel - Java Programming 9th Edition
        //All marks and students are stored inside the array
        // Array vs. ArrayList in Java Tutorial - What's The Difference? by Coding with John - https://www.youtube.com/watch?v=NbYgm0r7u6o
        ArrayList<student> students = new ArrayList<>();
        Scanner input = new Scanner(System.in);

        student Student = new student(0, 0.0, 0.0, "" ); // placeholder object

         int choice;

         //main application do loop
        do {
            System.out.println("\n===== STUDENT GRADEBOOK MENU =====");
            System.out.println("1. Add Student");
            System.out.println("2. Search Student");
            System.out.println("3. Remove Student");
            System.out.println("4. Print Report");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = input.nextInt();

            //Java switch ⬇【4 minutes】by Bro Code - https://www.youtube.com/watch?v=Om3qzMoaIUo
            switch (choice) {
                case 1:
                     Student.saveStudent(students);
                    break;
                case 2:
                    Student.searchStudent(students);
                    break;
                case 3:
                    Student.removeStudent(students);
                    break;
                case 4:
                    Student.printReport(students);
                    break;
                case 5:
                    System.out.println("Exiting application... Goodbye!");
                    break;
                    
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } 
        while (choice != 5);

        input.close();
    }
    
}
