package st10444823.sectionb.prog6112;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.*;


public class studentTest {

    private student studentApp;
    private ArrayList<student> students;

    @BeforeEach
    void setUp() {
        // Initializes a new student object and an empty list for each test
        student Student = new student(0, 0.0, 0.0, "" );
        students = new ArrayList<>();
    }

    @Test
    void testSaveStudent() {
        // Simulates user input for the saveStudent method
        String input = "12345\nJohn Doe\n85.5\n";
        studentApp.setInput(new Scanner(new ByteArrayInputStream(input.getBytes())));

        studentApp.saveStudent(students);

        // Verifies that the student was added and has the correct details
        assertEquals(1, students.size(), "ArrayList size should be 1 after adding a student.");
        assertEquals(12345, students.get(0).getId(), "ID should match input.");
        assertEquals("John Doe", students.get(0).getName(), "Name should match input.");
        assertEquals(85.5, students.get(0).getMark(), 0.001, "Mark should match input.");
    }
}